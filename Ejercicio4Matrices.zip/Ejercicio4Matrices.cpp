#include <iostream>
#include "Matriz.h"

using namespace std;

void mostrarMensajeBienvenida() {
    cout << "====================================" << endl;
    cout << "  Programa de Multiplicacion de Matrices" << endl;
    cout << "====================================" << endl;
}

void solicitarDimensiones(int& M, int& N, int& P) {
    cout << "Ingrese el numero de filas de la matriz A (M): ";
    cin >> M;
    cout << "Ingrese el numero de columnas de la matriz A y n�mero de filas de la matriz B (N): ";
    cin >> N;
    cout << "Ingrese el numero de columnas de la matriz B (P): ";
    cin >> P;
}

void mostrarResultados(const Matriz& A, const Matriz& B, const Matriz& C) {
    cout << "\nMatriz A:" << endl;
    A.imprimir();

    cout << "\nMatriz B:" << endl;
    B.imprimir();

    cout << "\nResultado de A x B (Matriz C):" << endl;
    C.imprimir();
}

int main() {
    mostrarMensajeBienvenida();

    int M, N, P;
    solicitarDimensiones(M, N, P);

    // Crear matrices
    Matriz A(M, N);
    Matriz B(N, P);
    Matriz C(M, P);

    // Solicitar al usuario que ingrese los valores de las matrices A y B
    A.ingresarDatos('A');
    B.ingresarDatos('B');

    // Multiplicar matrices
    A.multiplicar(B, C);

    // Mostrar los resultados
    mostrarResultados(A, B, C);

    cout << "\nPrograma finalizado." << endl;
    return 0;
}
