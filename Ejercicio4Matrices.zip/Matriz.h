#pragma once

class Matriz {
private:
    int filas;
    int columnas;
    int* datos;

public:
    Matriz(int filas, int columnas);
    ~Matriz();
    void ingresarDatos(char nombreMatriz);
    void imprimir() const;
    void multiplicar(const Matriz& otra, Matriz& resultado) const;
    int obtenerFilas() const;
    int obtenerColumnas() const;
    int* obtenerDatos() const;
};

