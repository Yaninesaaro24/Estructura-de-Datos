#include "Matriz.h"
#include <iostream>

using namespace std;

Matriz::Matriz(int filas, int columnas) : filas(filas), columnas(columnas) {
    datos = new int[filas * columnas];
}

Matriz::~Matriz() {
    delete[] datos;
}

void Matriz::ingresarDatos(char nombreMatriz) {
    cout << "Ingrese los valores de la matriz " << nombreMatriz << " de tama�o " << filas << "x" << columnas << ":" << endl;
    for (int i = 0; i < filas; ++i) {
        for (int j = 0; j < columnas; ++j) {
            cout << nombreMatriz << "[" << i << "][" << j << "]: ";
            cin >> datos[i * columnas + j];
        }
    }
}

void Matriz::imprimir() const {
    for (int i = 0; i < filas; ++i) {
        for (int j = 0; j < columnas; ++j) {
            cout << datos[i * columnas + j] << " ";
        }
        cout << endl;
    }
}

void Matriz::multiplicar(const Matriz& otra, Matriz& resultado) const {
    if (columnas != otra.obtenerFilas()) {
        cerr << "Las matrices no se pueden multiplicar debido a las dimensiones incompatibles." << endl;
        return;
    }

    int M = filas;
    int N = columnas;
    int P = otra.obtenerColumnas();
    int* datosA = datos;
    int* datosB = otra.obtenerDatos();
    int* datosC = resultado.obtenerDatos();

    // Inicializar la matriz resultado con ceros
    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < P; ++j) {
            datosC[i * P + j] = 0;
        }
    }

    // Multiplicar matrices
    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < P; ++j) {
            for (int k = 0; k < N; ++k) {
                datosC[i * P + j] += datosA[i * N + k] * datosB[k * P + j];
            }
        }
    }
}

int Matriz::obtenerFilas() const {
    return filas;
}

int Matriz::obtenerColumnas() const {
    return columnas;
}

int* Matriz::obtenerDatos() const {
    return datos;
}