#include <iostream>
#include "BibliotecaManager.h"

using namespace std;

int main() {
    BibliotecaManager sistema("biblioteca.dat");
    int opcion;
    do {
        cout << "\nMenu:\n";
        cout << "1. Agregar Libro\n";
        cout << "2. Mostrar Libros\n";
        cout << "3. Salir\n";
        cout << "Seleccione una opcion: ";
        cin >> opcion;
        switch (opcion) {
        case 1:
            sistema.agregarLibro();
            break;
        case 2:
            sistema.mostrarLibros();
            break;
        }
    } while (opcion != 3);
    return 0;
}
