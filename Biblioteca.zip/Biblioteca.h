#include <iostream>
#include <fstream>
#include <string>

using namespace std;

class Biblioteca {
private:
    string titulo;
    string autor;
    int a�o;

public:
    Biblioteca();
    Biblioteca(string tit, string aut, int an);

    void setLibro(string tit, string aut, int an);
    string getTitulo();
    string getAutor();
    int getA�o();

    void guardarArchivo(ofstream& fsalida);
    bool leerArchivo(ifstream& fentrada);
};
