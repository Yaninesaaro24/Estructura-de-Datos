#include "Biblioteca.h"

Biblioteca::Biblioteca() {
    titulo = "";
    autor = "";
    a�o = 0;
}

Biblioteca::Biblioteca(string tit, string aut, int an) {
    titulo = tit;
    autor = aut;
    a�o = an;
}

void Biblioteca::setLibro(string tit, string aut, int an) {
    titulo = tit;
    autor = aut;
    a�o = an;
}

string Biblioteca::getTitulo() {
    return titulo;
}

string Biblioteca::getAutor() {
    return autor;
}

int Biblioteca::getA�o() {
    return a�o;
}

void Biblioteca::guardarArchivo(ofstream& fsalida) {
    size_t tamTitulo = titulo.size();
    size_t tamAutor = autor.size();

    fsalida.write(reinterpret_cast<const char*>(&tamTitulo), sizeof(tamTitulo));
    fsalida.write(titulo.c_str(), tamTitulo);
    fsalida.write(reinterpret_cast<const char*>(&tamAutor), sizeof(tamAutor));
    fsalida.write(autor.c_str(), tamAutor);
    fsalida.write(reinterpret_cast<const char*>(&a�o), sizeof(a�o));
}

bool Biblioteca::leerArchivo(ifstream& fentrada) {
    size_t tamTitulo, tamAutor;

    if (fentrada.read(reinterpret_cast<char*>(&tamTitulo), sizeof(tamTitulo))) {
        char* bufferTitulo = new char[tamTitulo + 1];
        fentrada.read(bufferTitulo, tamTitulo);
        bufferTitulo[tamTitulo] = '\0';
        titulo = bufferTitulo;
        delete[] bufferTitulo;

        fentrada.read(reinterpret_cast<char*>(&tamAutor), sizeof(tamAutor));
        char* bufferAutor = new char[tamAutor + 1];
        fentrada.read(bufferAutor, tamAutor);
        bufferAutor[tamAutor] = '\0';
        autor = bufferAutor;
        delete[] bufferAutor;

        fentrada.read(reinterpret_cast<char*>(&a�o), sizeof(a�o));
        return true;
    }
    return false;
}
