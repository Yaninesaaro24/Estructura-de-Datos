# -*- coding: utf-8 -*-

class Biblioteca:
    def __init__(self, titulo="", autor="", a�o=0):
        self.titulo = titulo
        self.autor = autor
        self.a�o = a�o

    def set_libro(self, titulo, autor, a�o):
        self.titulo = titulo
        self.autor = autor
        self.a�o = a�o

    def get_titulo(self):
        return self.titulo

    def get_autor(self):
        return self.autor

    def get_a�o(self):
        return self.a�o

    def guardar_archivo(self, file):
        titulo_bytes = self.titulo.encode('utf-8')
        autor_bytes = self.autor.encode('utf-8')
        len_titulo = len(titulo_bytes)
        len_autor = len(autor_bytes)

        file.write(len_titulo.to_bytes(4, 'little'))
        file.write(titulo_bytes)
        file.write(len_autor.to_bytes(4, 'little'))
        file.write(autor_bytes)
        file.write(self.a�o.to_bytes(4, 'little'))

    def leer_archivo(self, file):
        len_titulo = int.from_bytes(file.read(4), 'little')
        self.titulo = file.read(len_titulo).decode('utf-8')
        len_autor = int.from_bytes(file.read(4), 'little')
        self.autor = file.read(len_autor).decode('utf-8')
        self.a�o = int.from_bytes(file.read(4), 'little')
        return True

    def __str__(self):
        return f"Titulo: {self.titulo}, Autor: {self.autor}, A�o: {self.a�o}"
