# -*- coding: utf-8 -*-

import os
from biblioteca import Biblioteca

class Nodo:
    def __init__(self, libro=None):
        self.libro = libro
        self.siguiente = None

class BibliotecaManager:
    def __init__(self, nom_archivo):
        self.nom_archivo = nom_archivo
        self.cabeza = None

    def agregar_libro(self):
        titulo = input("Titulo: ")
        autor = input("Autor: ")
        a�o = int(input("A�o: "))
        libro = Biblioteca(titulo, autor, a�o)
        with open(self.nom_archivo, 'ab') as file:
            libro.guardar_archivo(file)

    def leer_libros(self):
        if not os.path.exists(self.nom_archivo):
            print("El archivo no existe.")
            return
        
        self.cabeza = None
        ultimo = None
        with open(self.nom_archivo, 'rb') as file:
            while True:
                try:
                    libro = Biblioteca()
                    libro.leer_archivo(file)
                    nodo = Nodo(libro)
                    if not self.cabeza:
                        self.cabeza = nodo
                    else:
                        ultimo.siguiente = nodo
                    ultimo = nodo
                except:
                    break

    def mostrar_libros(self):
        self.leer_libros()
        print("Los libros en la biblioteca son --->>> :")
        actual = self.cabeza
        index = 1
        while actual is not None:
            print(f"{index}.- {actual.libro}")
            actual = actual.siguiente
            index += 1
