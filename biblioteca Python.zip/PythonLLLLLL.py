# -*- coding: utf-8 -*-

from biblioteca_manager import BibliotecaManager

def main():
    sistema = BibliotecaManager("biblioteca.dat")
    while True:
        print("\nMenu:")
        print("1. Agregar Libro")
        print("2. Mostrar Libros")
        print("3. Salir")
        opcion = int(input("Seleccione una opcion: "))
        if opcion == 1:
            sistema.agregar_libro()
        elif opcion == 2:
            sistema.mostrar_libros()
        elif opcion == 3:
            break
        else:
            print("Opci�n no v�lida")

if __name__ == "__main__":
    main()
