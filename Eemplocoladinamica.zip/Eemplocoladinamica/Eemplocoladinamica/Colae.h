
#pragma once
#include "Nodo.h"
#define MAX 100

class Colae
{
private:
	Nodo info[MAX];
	Nodo ini, fin;
public:
	Colae(void);
	bool Encolar(int Valor);
	bool Desencolar(void);
	bool PrimeroCola(int& Valor);
	bool ColaVacia(void);
	void mostrar(void);
};


