#include "Colae.h"
using namespace std;

Colae::Colae() {
    ini = 0;
    fin = 0;
}

bool Colae::Encolar(int Valor) {
    if ((fin + 1) % MAX == ini) // Verificar si la cola est� llena
        return false;
    info[fin] = Valor;
    fin = (fin + 1) % MAX;
    return true;
}

bool Colae::Desencolar() {
    if (ini == fin) // Verificar si la cola est� vac�a
        return false;
    ini = (ini + 1) % MAX;
    return true;
}

bool Colae::PrimeroCola(int& Valor) {
    if (ini == fin) // Verificar si la cola est� vac�a
        return false;
    Valor = info[ini];
    return true;
}

bool Colae::ColaVacia() {
    return ini == fin;
}

void Colae::mostrar() {
    if (ini == fin) {
   cout<< "La cola est� vac�a."<<endl;
        return;
    }

    cout<<"Elementos de la cola: ";
    int i = ini;
    while (i != fin) {
     cout << info[i] << " ";
        i = (i + 1) % MAX;
    }
    cout<<endl;
}
