
#pragma once 
#include <string>
using namespace std;
class Dato {
public:
    double Codigo;
    string Nombre;
    string Apellido;
    Dato() {
        Codigo = 0;
        Nombre = "Unknow";
        Apellido = "Unknow";
    }
};
