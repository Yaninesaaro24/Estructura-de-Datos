#pragma once
#include <string>
#include "Pago.h"
#include "RegistroEmpresa.h"
#include "RegistroProductos.h"
#include "RegistroServicios.h"

using namespace std;

class Empresa {
private:
    string nombreUsuario;
    string contrasena;
    string tipo;
    bool pagoRealizado;
    bool empresaRegistrada;
    Pago pago;
    RegistroEmpresa registroEmpresa;
    RegistroProductos registroProductos;
    RegistroServicios registroServicios;
    Empresa* siguiente;

    void realizarPago();
    void registrarEmpresa();
    void registrarProducto();
    void registrarServicio();
    void mostrarServicios();
    void mostrarProductos();
    void modificarInformacion();
    void esperarEnter() const;
    void limpiarPantalla() const;

public:
    Empresa(const string& nombreUsuario = "", const string& contrasena = "", const string& tipo = "");
    Empresa(const Empresa& other);
    Empresa& operator=(const Empresa& other);
    ~Empresa();

    void menuEmpresa();
    Empresa* getSiguiente() const;
    void setSiguiente(Empresa* siguiente);
};
