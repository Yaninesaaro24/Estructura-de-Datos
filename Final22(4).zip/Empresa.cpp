#include "Empresa.h"
#include <iostream>
#include <fstream>
#include <limits>

using namespace std;

Empresa::Empresa(const string& nombreUsuario, const string& contrasena, const string& tipo)
    : nombreUsuario(nombreUsuario), contrasena(contrasena), tipo(tipo),
    pagoRealizado(false), empresaRegistrada(false),
    siguiente(nullptr) {}

Empresa::Empresa(const Empresa& other)
    : nombreUsuario(other.nombreUsuario), contrasena(other.contrasena), tipo(other.tipo),
    pagoRealizado(other.pagoRealizado), empresaRegistrada(other.empresaRegistrada),
    pago(other.pago), registroEmpresa(other.registroEmpresa),
    registroProductos(other.registroProductos), registroServicios(other.registroServicios),
    siguiente(nullptr) {}

Empresa& Empresa::operator=(const Empresa& other) {
    if (this != &other) {
        nombreUsuario = other.nombreUsuario;
        contrasena = other.contrasena;
        tipo = other.tipo;
        pagoRealizado = other.pagoRealizado;
        empresaRegistrada = other.empresaRegistrada;
        pago = other.pago;
        registroEmpresa = other.registroEmpresa;
        registroProductos = other.registroProductos;
        registroServicios = other.registroServicios;
        siguiente = nullptr;
    }
    return *this;
}

Empresa::~Empresa() {}

void Empresa::limpiarPantalla() const {
    system("CLS"); // Funciona en Windows
}

void Empresa::esperarEnter() const {
    cout << "\nPresione Enter para continuar...";
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cin.get();
}

void Empresa::realizarPago() {
    if (pago.realizarPago()) {
        pagoRealizado = true;
        cout << "Pago realizado. Ahora puede registrar su empresa.\n";
    }
    else {
        cout << "Pago no realizado. No puede registrar su empresa.\n";
    }
}

void Empresa::registrarEmpresa() {
    if (!empresaRegistrada) {
        cout << "Registrar la empresa.\n";
        registroEmpresa.registrarEmpresa();
        empresaRegistrada = true;
    }
    else {
        cout << "La empresa ya est� registrada.\n";
    }
}

void Empresa::registrarProducto() {
    registroProductos.registrar();
}

void Empresa::registrarServicio() {
    registroServicios.registrar();
}

void Empresa::mostrarServicios() {
    cout << "Servicios:\n";
    registroServicios.mostrar();
}

void Empresa::mostrarProductos() {
    cout << "Productos:\n";
    registroProductos.mostrar();
}

void Empresa::modificarInformacion() {
    registroEmpresa.modificarEmpresa();
}

void Empresa::menuEmpresa() {
    int opcion;
    while (true) {
        limpiarPantalla();
        cout << "\n==============================\n";
        cout << "       Menu de la Empresa     \n";
        cout << "==============================\n";
        if (!pagoRealizado) {
            cout << "1. Realizar Pago de Membresia\n";
            cout << "2. Salir\n";
        }
        else if (!empresaRegistrada) {
            cout << "1. Registrar Empresa\n";
            cout << "2. Salir\n";
        }
        else {
            cout << "1. Registrar Producto\n";
            cout << "2. Registrar Servicio\n";
            cout << "3. Mostrar Servicios\n";
            cout << "4. Mostrar Productos\n";
            cout << "5. Modificar Informacion\n";
            cout << "6. Salir\n";
        }
        cout << "------------------------------\n";
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        if (cin.fail() || (!pagoRealizado && (opcion < 1 || opcion > 2)) ||
            (pagoRealizado && !empresaRegistrada && (opcion < 1 || opcion > 2)) ||
            (pagoRealizado && empresaRegistrada && (opcion < 1 || opcion > 6))) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Opcion no valida. Presione Enter para intentar de nuevo.";
            esperarEnter();
            continue;
        }

        switch (opcion) {
        case 1:
            if (!pagoRealizado) {
                realizarPago();
            }
            else if (!empresaRegistrada) {
                registrarEmpresa();
            }
            else {
                registrarProducto();
            }
            break;
        case 2:
            if (!pagoRealizado || !empresaRegistrada) {
                return;
            }
            else {
                registrarServicio();
            }
            break;
        case 3:
            mostrarServicios();
            break;
        case 4:
            mostrarProductos();
            break;
        case 5:
            modificarInformacion();
            break;
        case 6:
            return; // Salir al menu principal
        }
        esperarEnter();
    }
}

Empresa* Empresa::getSiguiente() const {
    return siguiente;
}

void Empresa::setSiguiente(Empresa* siguiente) {
    this->siguiente = siguiente;
}
