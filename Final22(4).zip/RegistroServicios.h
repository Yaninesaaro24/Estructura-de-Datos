#pragma once
#include <string>
#include <fstream>
#include "RegistroMantenimientoPreventivo.h"
#include "RegistroMantenimientoCorrectivo.h"

using namespace std;

class RegistroServicios {
private:
    RegistroMantenimientoPreventivo registroMantenimientoPreventivo;
    RegistroMantenimientoCorrectivo registroMantenimientoCorrectivo;

public:
    RegistroServicios();
    void registrar();
    void mostrar() const;
};
