#pragma once
#include <string>
#include "BuscarProductos.h"
#include "BuscarServicios.h"
#include "ControlMantenimientoPreventivo.h"
#include "RegistroEmpresa.h"
#include "Pago.h"
#include <iostream>
#include <limits>

using namespace std;

class Cliente {
private:
    string nombreUsuario;
    string contrasena;
    string tipo;
    bool esPremium;
    Cliente* siguiente; // Para la lista enlazada

    void guardarCliente() const;
    bool existeCliente(const string& nombreUsuario) const;
    void esperarEnter() const;
    void limpiarPantalla() const;

public:
    Cliente(const string& nombreUsuario = "", const string& contrasena = "", const string& tipo = "");
    ~Cliente();

    bool registrarCliente();
    bool iniciarSesion(const string& nombreUsuario, const string& contrasena);
    string getTipo() const;
    string getNombreUsuario() const;

    Cliente* getSiguiente() const;
    void setSiguiente(Cliente* siguiente);

    void buscarProductos() const;
    void buscarServicios() const;
    void controlMantenimientoPreventivo() const;
    void cuentaPremium();
};
