#pragma once
#include <string>

using namespace std;

class NodoAccesorio {
public:
    string nombre;
    float precio;
    NodoAccesorio* siguiente;

    NodoAccesorio(const string& nombre, float precio)
        : nombre(nombre), precio(precio), siguiente(nullptr) {}
};

class RegistroAccesorios {
private:
    NodoAccesorio* tope;

    void guardarAccesorio(const NodoAccesorio* accesorio) const;

public:
    RegistroAccesorios();
    ~RegistroAccesorios();

    void registrar();
    void mostrar() const;
};
