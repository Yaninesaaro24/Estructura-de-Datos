#include "RegistroProductos.h"
#include <iostream>

using namespace std;

RegistroProductos::RegistroProductos() {}

void RegistroProductos::registrar() {
    int opcion;
    cout << "Seleccione el tipo de producto:\n";
    cout << "1. Accesorios\n";
    cout << "2. Repuestos\n";
    cin >> opcion;

    switch (opcion) {
    case 1:
        registroAccesorios.registrar();
        break;
    case 2:
        registroRepuestos.registrar();
        break;
    default:
        cout << "Opci�n no v�lida.\n";
        break;
    }
}

void RegistroProductos::mostrar() const {
    cout << "Accesorios:\n";
    registroAccesorios.mostrar();
    cout << "\nRepuestos:\n";
    registroRepuestos.mostrar();
}
