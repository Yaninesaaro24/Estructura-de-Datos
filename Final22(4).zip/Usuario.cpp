#include "Usuario.h"

Usuario::Usuario() : nombreUsuario(""), contrasena(""), tipo("") {}

Usuario::Usuario(const string& nombreUsuario, const string& contrasena, const string& tipo)
    : nombreUsuario(nombreUsuario), contrasena(contrasena), tipo(tipo) {}

void Usuario::limpiarPantalla() const {
    system("CLS"); // Funciona en Windows
}

bool Usuario::registrarUsuario() {
    ifstream archivo("usuarios.dat", ios::binary);
    string linea;
    while (getline(archivo, linea)) {
        if (linea.find(nombreUsuario) != string::npos) {
            archivo.close();
            return false;
        }
    }
    archivo.close();

    ofstream archivoOut("usuarios.dat", ios::binary | ios::app);
    if (archivoOut.is_open()) {
        int nombreLen = nombreUsuario.size();
        int passLen = contrasena.size();
        int tipoLen = tipo.size();

        archivoOut.write(reinterpret_cast<const char*>(&nombreLen), sizeof(nombreLen));
        archivoOut.write(nombreUsuario.c_str(), nombreLen);
        archivoOut.write(reinterpret_cast<const char*>(&passLen), sizeof(passLen));
        archivoOut.write(contrasena.c_str(), passLen);
        archivoOut.write(reinterpret_cast<const char*>(&tipoLen), sizeof(tipoLen));
        archivoOut.write(tipo.c_str(), tipoLen);

        archivoOut.close();
        return true;
    }
    return false;
}

bool Usuario::iniciarSesion(const string& nombreUsuario, const string& contrasena) {
    ifstream archivo("usuarios.dat", ios::binary);
    if (archivo.is_open()) {
        while (archivo.peek() != EOF) {
            int nombreLen;
            archivo.read(reinterpret_cast<char*>(&nombreLen), sizeof(nombreLen));
            string nombre;
            nombre.resize(nombreLen);
            archivo.read(&nombre[0], nombreLen);

            int passLen;
            archivo.read(reinterpret_cast<char*>(&passLen), sizeof(passLen));
            string pass;
            pass.resize(passLen);
            archivo.read(&pass[0], passLen);

            int tipoLen;
            archivo.read(reinterpret_cast<char*>(&tipoLen), sizeof(tipoLen));
            string tipo;
            tipo.resize(tipoLen);
            archivo.read(&tipo[0], tipoLen);

            if (nombre == nombreUsuario && pass == contrasena) {
                archivo.close();
                this->nombreUsuario = nombreUsuario;
                this->contrasena = contrasena;
                this->tipo = tipo;
                return true;
            }
        }
        archivo.close();
    }
    return false;
}

string Usuario::getNombreUsuario() const {
    return nombreUsuario;
}

string Usuario::getContrasena() const {
    return contrasena;
}

string Usuario::getTipo() const {
    return tipo;
}

void Usuario::buscarProductos() const {
    Cliente cliente(nombreUsuario, contrasena, tipo);
    cliente.buscarProductos();
}

void Usuario::buscarServicios() const {
    Cliente cliente(nombreUsuario, contrasena, tipo);
    cliente.buscarServicios();
}

void Usuario::cuentaPremium() const {
    Cliente cliente(nombreUsuario, contrasena, tipo);
    cliente.cuentaPremium();
}
