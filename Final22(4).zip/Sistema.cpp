#include "Sistema.h"
#include <iostream>
#include <limits>

using namespace std;

Sistema::Sistema() : empresa(nullptr) {}

Sistema::~Sistema() {
    delete empresa; // Liberar memoria
}

void Sistema::limpiarPantalla() const {
    system("CLS"); // Funciona en Windows
}

void Sistema::esperarEnter() const {
    cout << "\nPresione Enter para continuar...";
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cin.get();
}

void Sistema::iniciar() {
    while (true) {
        menuPrincipal();
    }
}

void Sistema::menuPrincipal() {
    int opcion;
    while (true) {
        limpiarPantalla();
        cout << "==============================\n";
        cout << "  Bienvenido a la Aplicacion  \n";
        cout << "        de Vehiculos          \n";
        cout << "==============================\n";
        cout << "1. Registrarse\n";
        cout << "2. Iniciar Sesion\n";
        cout << "3. Salir\n";
        cout << "------------------------------\n";
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        if (cin.fail() || opcion < 1 || opcion > 3) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Opcion no valida. Presione Enter para intentar de nuevo.";
            esperarEnter();
            continue;
        }

        switch (opcion) {
        case 1:
            registrarUsuario();
            break;
        case 2:
            iniciarSesion();
            break;
        case 3:
            cout << "Gracias por usar la aplicacion. Adios!\n";
            exit(0);
        }
    }
}

void Sistema::registrarUsuario() {
    string nombreUsuario, contrasena, tipo;
    limpiarPantalla();
    cout << "\n==============================\n";
    cout << "     Registro de Usuario      \n";
    cout << "==============================\n";
    cout << "Ingrese nombre de usuario: ";
    cin >> nombreUsuario;
    cin.ignore();
    cout << "Ingrese contrasena: ";
    getline(cin, contrasena);
    cout << "Ingrese tipo de usuario (Cliente/Empresa): ";
    getline(cin, tipo);

    Usuario usuario(nombreUsuario, contrasena, tipo);
    if (!usuario.registrarUsuario()) {
        cout << "El usuario ya existe. Intente nuevamente.\n";
        esperarEnter();
    }
    else {
        cout << "Usuario registrado con exito.\n";
        esperarEnter();
    }
}

void Sistema::iniciarSesion() {
    string nombreUsuario, contrasena;
    limpiarPantalla();
    cout << "\n==============================\n";
    cout << "      Inicio de Sesion        \n";
    cout << "==============================\n";
    cout << "Ingrese nombre de usuario: ";
    cin >> nombreUsuario;
    cin.ignore();
    cout << "Ingrese contrasena: ";
    getline(cin, contrasena);

    Usuario usuario;
    if (usuario.iniciarSesion(nombreUsuario, contrasena)) {
        usuarioActual = usuario; // Establecer el usuario actual
        if (usuarioActual.getTipo() == "Cliente") {
            menuCliente();
        }
        else if (usuarioActual.getTipo() == "Empresa") {
            empresa = new Empresa(nombreUsuario, contrasena, "Empresa");
            empresa->menuEmpresa();
        }
    }
    else {
        cout << "Error al iniciar sesion. Intente nuevamente.\n";
        esperarEnter();
    }
}

void Sistema::menuCliente() {
    int opcion;
    while (true) {
        limpiarPantalla();
        cout << "\n==============================\n";
        cout << "       Menu del Cliente       \n";
        cout << "==============================\n";
        cout << "1. Buscar Producto\n";
        cout << "2. Buscar Servicio\n";
        cout << "3. Opcion Premium\n";
        cout << "4. Salir\n";
        cout << "------------------------------\n";
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        if (cin.fail() || opcion < 1 || opcion > 4) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Opcion no valida. Presione Enter para intentar de nuevo.";
            esperarEnter();
            continue;
        }

        switch (opcion) {
        case 1:
            usuarioActual.buscarProductos();
            break;
        case 2:
            usuarioActual.buscarServicios();
            break;
        case 3:
            usuarioActual.cuentaPremium();
            break;
        case 4:
            return;
        }
        esperarEnter();
    }
}

void Sistema::menuEmpresa() {
    if (empresa) {
        empresa->menuEmpresa();
    }
}
