#pragma once
#include "Usuario.h"
#include "Empresa.h"
#include "Cliente.h"
#include <iostream>
#include <limits>

using namespace std;

class Sistema {
public:
    Sistema();
    ~Sistema();
    void iniciar();
private:
    Usuario usuarioActual;
    Empresa* empresa;
    Cliente* cliente;

    void menuPrincipal();
    void registrarUsuario();
    void iniciarSesion();
    void menuCliente();
    void menuEmpresa();
    void esperarEnter() const;
    void limpiarPantalla() const;
};
