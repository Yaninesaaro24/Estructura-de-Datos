#include "RegistroRepuestos.h"
#include <fstream>
#include <iostream>

using namespace std;

RegistroRepuestos::RegistroRepuestos() : tope(nullptr) {}

RegistroRepuestos::~RegistroRepuestos() {
    while (tope != nullptr) {
        NodoProducto* temp = tope;
        tope = tope->siguiente;
        delete temp;
    }
}

void RegistroRepuestos::guardarProducto(const NodoProducto* producto) const {
    ofstream outFile("repuestos.dat", ios::app | ios::binary);
    if (outFile.is_open()) {
        int nombreLen = producto->nombre.size();

        outFile.write(reinterpret_cast<const char*>(&nombreLen), sizeof(int));
        outFile.write(producto->nombre.c_str(), nombreLen);
        outFile.write(reinterpret_cast<const char*>(&producto->precio), sizeof(float));

        outFile.close();
        cout << "Producto registrado con exito.\n";
    }
    else {
        cout << "Error al registrar el producto.\n";
    }
}

void RegistroRepuestos::registrar() {
    int opcion1, opcion2;
    cout << "Seleccione la categoria de repuesto:\n";
    cout << "1. Motor\n";
    cout << "2. Suspension/Direccion\n";
    cout << "3. Caja y Roster Corona Palier Cardan\n";
    cout << "4. Sistema Electrico\n";
    cout << "5. Frenos y Embrague\n";
    cout << "6. Filtros\n";
    cout << "7. Piezas de Carroceria\n";
    cout << "8. Retenes Rodamientos Crucetas y Correas\n";
    cin >> opcion1;

    string nombre;
    float precio;
    bool valido = true;

    switch (opcion1) {
    case 1:
        cout << "Seleccione el repuesto del motor:\n";
        cout << "1. Pistones (400-1200 Bs.)\n";
        cout << "2. Juntas de culata (300-800 Bs.)\n";
        cin >> opcion2;
        if (opcion2 == 1) {
            nombre = "Pistones";
            cout << "Ingrese el precio (400-1200 Bs.): ";
            cin >> precio;
            valido = (precio >= 400 && precio <= 1200);
        }
        else if (opcion2 == 2) {
            nombre = "Juntas de culata";
            cout << "Ingrese el precio (300-800 Bs.): ";
            cin >> precio;
            valido = (precio >= 300 && precio <= 800);
        }
        else {
            cout << "Opcion no valida.\n";
            return;
        }
        break;
    case 2:
        cout << "Seleccione el repuesto de suspension/direccion:\n";
        cout << "1. Amortiguadores (300-800 Bs.)\n";
        cout << "2. Cremalleras de direccion (800-2000 Bs.)\n";
        cin >> opcion2;
        if (opcion2 == 1) {
            nombre = "Amortiguadores";
            cout << "Ingrese el precio (300-800 Bs.): ";
            cin >> precio;
            valido = (precio >= 300 && precio <= 800);
        }
        else if (opcion2 == 2) {
            nombre = "Cremalleras de direccion";
            cout << "Ingrese el precio (800-2000 Bs.): ";
            cin >> precio;
            valido = (precio >= 800 && precio <= 2000);
        }
        else {
            cout << "Opcion no valida.\n";
            return;
        }
        break;
    case 3:
        cout << "Seleccione el repuesto de caja y roster corona palier cardan:\n";
        cout << "1. Ejes de transmision (Palier) (500-1500 Bs.)\n";
        cout << "2. Cardan (1000-3000 Bs.)\n";
        cin >> opcion2;
        if (opcion2 == 1) {
            nombre = "Ejes de transmision (Palier)";
            cout << "Ingrese el precio (500-1500 Bs.): ";
            cin >> precio;
            valido = (precio >= 500 && precio <= 1500);
        }
        else if (opcion2 == 2) {
            nombre = "Cardan";
            cout << "Ingrese el precio (1000-3000 Bs.): ";
            cin >> precio;
            valido = (precio >= 1000 && precio <= 3000);
        }
        else {
            cout << "Opcion no valida.\n";
            return;
        }
        break;
    case 4:
        cout << "Seleccione el repuesto del sistema electrico:\n";
        cout << "1. Baterias (300-800 Bs.)\n";
        cout << "2. Alternadores (500-1500 Bs.)\n";
        cin >> opcion2;
        if (opcion2 == 1) {
            nombre = "Baterias";
            cout << "Ingrese el precio (300-800 Bs.): ";
            cin >> precio;
            valido = (precio >= 300 && precio <= 800);
        }
        else if (opcion2 == 2) {
            nombre = "Alternadores";
            cout << "Ingrese el precio (500-1500 Bs.): ";
            cin >> precio;
            valido = (precio >= 500 && precio <= 1500);
        }
        else {
            cout << "Opcion no valida.\n";
            return;
        }
        break;
    case 5:
        cout << "Seleccione el repuesto de frenos y embrague:\n";
        cout << "1. Discos de freno (200-600 Bs.)\n";
        cout << "2. Pastillas de freno (100-300 Bs.)\n";
        cout << "3. Embragues (800-2000 Bs.)\n";
        cin >> opcion2;
        if (opcion2 == 1) {
            nombre = "Discos de freno";
            cout << "Ingrese el precio (200-600 Bs.): ";
            cin >> precio;
            valido = (precio >= 200 && precio <= 600);
        }
        else if (opcion2 == 2) {
            nombre = "Pastillas de freno";
            cout << "Ingrese el precio (100-300 Bs.): ";
            cin >> precio;
            valido = (precio >= 100 && precio <= 300);
        }
        else if (opcion2 == 3) {
            nombre = "Embragues";
            cout << "Ingrese el precio (800-2000 Bs.): ";
            cin >> precio;
            valido = (precio >= 800 && precio <= 2000);
        }
        else {
            cout << "Opcion no valida.\n";
            return;
        }
        break;
    case 6:
        cout << "Seleccione el repuesto de filtros:\n";
        cout << "1. Filtros de aire (50-150 Bs.)\n";
        cout << "2. Filtros de aceite (50-150 Bs.)\n";
        cin >> opcion2;
        if (opcion2 == 1) {
            nombre = "Filtros de aire";
            cout << "Ingrese el precio (50-150 Bs.): ";
            cin >> precio;
            valido = (precio >= 50 && precio <= 150);
        }
        else if (opcion2 == 2) {
            nombre = "Filtros de aceite";
            cout << "Ingrese el precio (50-150 Bs.): ";
            cin >> precio;
            valido = (precio >= 50 && precio <= 150);
        }
        else {
            cout << "Opcion no valida.\n";
            return;
        }
        break;
    case 7:
        cout << "Seleccione el repuesto de piezas de carroceria:\n";
        cout << "1. Parachoques (600-2000 Bs.)\n";
        cout << "2. Faros y luces traseras (200-800 Bs.)\n";
        cin >> opcion2;
        if (opcion2 == 1) {
            nombre = "Parachoques";
            cout << "Ingrese el precio (600-2000 Bs.): ";
            cin >> precio;
            valido = (precio >= 600 && precio <= 2000);
        }
        else if (opcion2 == 2) {
            nombre = "Faros y luces traseras";
            cout << "Ingrese el precio (200-800 Bs.): ";
            cin >> precio;
            valido = (precio >= 200 && precio <= 800);
        }
        else {
            cout << "Opcion no valida.\n";
            return;
        }
        break;
    case 8:
        cout << "Seleccione el repuesto de retenes rodamientos crucetas y correas:\n";
        cout << "1. Rodamientos (100-400 Bs.)\n";
        cout << "2. Correas de distribucion (200-800 Bs.)\n";
        cin >> opcion2;
        if (opcion2 == 1) {
            nombre = "Rodamientos";
            cout << "Ingrese el precio (100-400 Bs.): ";
            cin >> precio;
            valido = (precio >= 100 && precio <= 400);
        }
        else if (opcion2 == 2) {
            nombre = "Correas de distribucion";
            cout << "Ingrese el precio (200-800 Bs.): ";
            cin >> precio;
            valido = (precio >= 200 && precio <= 800);
        }
        else {
            cout << "Opcion no valida.\n";
            return;
        }
        break;
    default:
        cout << "Opcion no valida.\n";
        return;
    }

    if (!valido) {
        cout << "El precio ingresado no esta en el rango permitido. Registro cancelado.\n";
        return;
    }

    NodoProducto* nuevoProducto = new NodoProducto(nombre, precio);
    nuevoProducto->siguiente = tope;
    tope = nuevoProducto;
    guardarProducto(nuevoProducto);
}

void RegistroRepuestos::mostrar() const {
    ifstream inFile("repuestos.dat", ios::binary);
    if (!inFile) {
        cerr << "Error al abrir el archivo" << endl;
        return;
    }

    while (inFile.peek() != EOF) {
        int nombreLen;
        inFile.read(reinterpret_cast<char*>(&nombreLen), sizeof(int));

        char* nombreBuffer = new char[nombreLen + 1];
        inFile.read(nombreBuffer, nombreLen);
        nombreBuffer[nombreLen] = '\0';
        string nombre = string(nombreBuffer);
        delete[] nombreBuffer;

        float precio;
        inFile.read(reinterpret_cast<char*>(&precio), sizeof(float));

        cout << "Nombre: " << nombre << endl;
        cout << "Precio: " << precio << " Bs." << endl;
    }

    inFile.close();
}
