#pragma once
#include <string>
#include "RegistroProductos.h"

class BuscarProductos {
private:
    RegistroProductos registroProductos;

public:
    void buscar() const;
    void filtrarPorPrecio() const;
    void filtrarPorUbicacion() const;
};
