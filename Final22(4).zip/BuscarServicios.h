#pragma once
#include <string>
#include "RegistroServicios.h"

class BuscarServicios {
private:
    RegistroServicios registroServicios;

public:
    void buscar() const;
    void filtrarPorPrecio() const;
    void filtrarPorUbicacion() const;
};