#pragma once
#include <string>

using namespace std;

class NodoServicioCorrectivo {
public:
    string nombre;
    float precio;
    int duracion;
    NodoServicioCorrectivo* siguiente;

    NodoServicioCorrectivo(const string& nombre, float precio, int duracion)
        : nombre(nombre), precio(precio), duracion(duracion), siguiente(nullptr) {}
};

class RegistroMantenimientoCorrectivo {
private:
    NodoServicioCorrectivo* frente;
    NodoServicioCorrectivo* fondo;

    void guardarServicio(const NodoServicioCorrectivo* servicio) const;

public:
    RegistroMantenimientoCorrectivo();
    ~RegistroMantenimientoCorrectivo();

    void registrar();
    void mostrar() const;
};

