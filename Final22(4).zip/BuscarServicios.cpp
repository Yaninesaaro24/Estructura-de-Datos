#include "BuscarServicios.h"
#include <iostream>
#include <fstream>
#include "RegistroEmpresa.h"

using namespace std;

void BuscarServicios::buscar() const {
    registroServicios.mostrar();
}

void BuscarServicios::filtrarPorPrecio() const {
    float precioMin, precioMax;
    cout << "Ingrese el precio minimo: ";
    cin >> precioMin;
    cout << "Ingrese el precio maximo: ";
    cin >> precioMax;

    ifstream inFile("servicios.dat", ios::binary);
    if (inFile.is_open()) {
        while (inFile.peek() != EOF) {
            string nombre, empresaNIT;
            float precio;
            int duracion;
            int len;

            inFile.read(reinterpret_cast<char*>(&len), sizeof(len));
            nombre.resize(len);
            inFile.read(&nombre[0], len);
            inFile.read(reinterpret_cast<char*>(&precio), sizeof(precio));
            inFile.read(reinterpret_cast<char*>(&duracion), sizeof(duracion));
            inFile.read(reinterpret_cast<char*>(&len), sizeof(len));
            empresaNIT.resize(len);
            inFile.read(&empresaNIT[0], len);

            if (precio >= precioMin && precio <= precioMax) {
                RegistroEmpresa empresa;
                if (empresa.cargarDesdeArchivo(empresaNIT)) {
                    cout << "Nombre: " << nombre << ", Precio: " << precio << " Bs, Duracion: " << duracion << " minutos" << endl;
                    empresa.mostrarEmpresa();
                }
            }
        }
        inFile.close();
    }
    else {
        cout << "Error al abrir el archivo de servicios.\n";
    }
}

void BuscarServicios::filtrarPorUbicacion() const {
    string zona;
    int anilloInicio, anilloFin;
    cout << "Ingrese su zona (Norte, Sur, Este, Oeste): ";
    cin >> zona;
    cout << "Ingrese el anillo inicial (1-12): ";
    cin >> anilloInicio;
    cout << "Ingrese el anillo final (1-12): ";
    cin >> anilloFin;

    ifstream inFile("servicios.dat", ios::binary);
    if (inFile.is_open()) {
        while (inFile.peek() != EOF) {
            string nombre, empresaNIT;
            float precio;
            int duracion;
            int len;

            inFile.read(reinterpret_cast<char*>(&len), sizeof(len));
            nombre.resize(len);
            inFile.read(&nombre[0], len);
            inFile.read(reinterpret_cast<char*>(&precio), sizeof(precio));
            inFile.read(reinterpret_cast<char*>(&duracion), sizeof(duracion));
            inFile.read(reinterpret_cast<char*>(&len), sizeof(len));
            empresaNIT.resize(len);
            inFile.read(&empresaNIT[0], len);

            RegistroEmpresa empresa;
            if (empresa.cargarDesdeArchivo(empresaNIT)) {
                if (empresa.getUbicacion().getZona() == zona &&
                    empresa.getUbicacion().getAnilloInicio() <= anilloFin &&
                    empresa.getUbicacion().getAnilloFin() >= anilloInicio) {
                    cout << "Nombre: " << nombre << ", Precio: " << precio << " Bs, Duracion: " << duracion << " minutos" << endl;
                    empresa.mostrarEmpresa();
                }
            }
        }
        inFile.close();
    }
    else {
        cout << "Error al abrir el archivo de servicios.\n";
    }
}
