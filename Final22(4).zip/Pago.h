#pragma once
#include <string>
#include <ctime>
#include <iostream>
#include <fstream>

using namespace std;

class Pago {
private:
    string metodo;
    double monto;
    string moneda;
    time_t timestamp;

    void realizarPago(double monto, const string& moneda, const string& metodo);
    void guardarTransaccion() const;

    int mostrarMenuPago();
    bool confirmarCompra();

public:
    bool realizarPago();
};

