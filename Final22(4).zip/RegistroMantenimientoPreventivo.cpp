#include "RegistroMantenimientoPreventivo.h"

RegistroMantenimientoPreventivo::RegistroMantenimientoPreventivo() : frente(nullptr), fondo(nullptr) {}

RegistroMantenimientoPreventivo::~RegistroMantenimientoPreventivo() {
    while (frente != nullptr) {
        NodoServicio* temp = frente;
        frente = frente->siguiente;
        delete temp;
    }
}

void RegistroMantenimientoPreventivo::guardarServicio(const NodoServicio* servicio) const {
    ofstream outFile("mantenimiento_preventivo.dat", ios::binary | ios::app);
    if (outFile.is_open()) {
        int nombreLen = servicio->nombre.size();
        outFile.write(reinterpret_cast<const char*>(&nombreLen), sizeof(int));
        outFile.write(servicio->nombre.c_str(), nombreLen);
        outFile.write(reinterpret_cast<const char*>(&servicio->precio), sizeof(float));
        outFile.write(reinterpret_cast<const char*>(&servicio->duracion), sizeof(int));
        outFile.close();
    }
    else {
        cout << "Error al registrar el servicio.\n";
    }
}

void RegistroMantenimientoPreventivo::registrar() {
    int opcion;
    cout << "Seleccione el servicio de mantenimiento preventivo:\n";
    cout << "1. Cambio de Aceite y Filtro (100-200 Bs. 30-60 minutos)\n";
    cout << "2. Revisi�n y Relleno de Fluidos (50-100 Bs. 30-60 minutos)\n";
    cout << "3. Rotaci�n de Neum�ticos (50-100 Bs. 30-60 minutos)\n";
    cout << "4. Alineaci�n y Balanceo de Neum�ticos (150-300 Bs. 1-2 horas)\n";
    cout << "5. Revisi�n de Frenos (100-200 Bs. 1-2 horas)\n";
    cin >> opcion;

    string nombre;
    float precio;
    int duracion;

    switch (opcion) {
    case 1:
        nombre = "Cambio de Aceite y Filtro";
        precio = 100 + rand() % 101;  // Precio aleatorio entre 100 y 200
        duracion = 30 + rand() % 31;  // Duraci�n aleatoria entre 30 y 60 minutos
        break;
    case 2:
        nombre = "Revisi�n y Relleno de Fluidos";
        precio = 50 + rand() % 51;  // Precio aleatorio entre 50 y 100
        duracion = 30 + rand() % 31;
        break;
    case 3:
        nombre = "Rotaci�n de Neum�ticos";
        precio = 50 + rand() % 51;
        duracion = 30 + rand() % 31;
        break;
    case 4:
        nombre = "Alineaci�n y Balanceo de Neum�ticos";
        precio = 150 + rand() % 151;  // Precio aleatorio entre 150 y 300
        duracion = 60 + rand() % 61;  // Duraci�n aleatoria entre 60 y 120 minutos
        break;
    case 5:
        nombre = "Revisi�n de Frenos";
        precio = 100 + rand() % 101;
        duracion = 60 + rand() % 61;
        break;
    default:
        cout << "Opci�n no v�lida.\n";
        return;
    }

    NodoServicio* nuevoServicio = new NodoServicio(nombre, precio, duracion);
    if (fondo == nullptr) {
        frente = fondo = nuevoServicio;
    }
    else {
        fondo->siguiente = nuevoServicio;
        fondo = nuevoServicio;
    }
    guardarServicio(nuevoServicio);
}

void RegistroMantenimientoPreventivo::mostrar() const {
    NodoServicio* actual = frente;
    while (actual != nullptr) {
        cout << "Nombre: " << actual->nombre << endl;
        cout << "Precio: " << actual->precio << " Bs." << endl;
        cout << "Duraci�n: " << actual->duracion << " minutos" << endl;
        actual = actual->siguiente;
    }
}
