#include "Ubicacion.h"
#include <iostream>

using namespace std;

Ubicacion::Ubicacion() : anilloInicio(0), anilloFin(0) {}

void Ubicacion::registrarUbicacion() {
    cout << "Ingrese la zona (Norte, Sur, Este, Oeste): ";
    cin >> zona;
    cout << "Ingrese el anillo inicial (1-12): ";
    cin >> anilloInicio;
    cout << "Ingrese el anillo final (1-12): ";
    cin >> anilloFin;
}

string Ubicacion::getZona() const {
    return zona;
}

int Ubicacion::getAnilloInicio() const {
    return anilloInicio;
}

int Ubicacion::getAnilloFin() const {
    return anilloFin;
}

void Ubicacion::setZona(const string& zona) {
    this->zona = zona;
}

void Ubicacion::setAnilloInicio(int anilloInicio) {
    this->anilloInicio = anilloInicio;
}

void Ubicacion::setAnilloFin(int anilloFin) {
    this->anilloFin = anilloFin;
}

void Ubicacion::guardarEnArchivo(ofstream& archivo) const {
    int zonaLen = zona.size();

    archivo.write(reinterpret_cast<const char*>(&zonaLen), sizeof(int));
    archivo.write(zona.c_str(), zonaLen);
    archivo.write(reinterpret_cast<const char*>(&anilloInicio), sizeof(int));
    archivo.write(reinterpret_cast<const char*>(&anilloFin), sizeof(int));
}

void Ubicacion::cargarDesdeArchivo(ifstream& archivo) {
    int zonaLen;

    archivo.read(reinterpret_cast<char*>(&zonaLen), sizeof(int));
    char* zonaTemp = new char[zonaLen + 1];
    archivo.read(zonaTemp, zonaLen);
    zonaTemp[zonaLen] = '\0';
    zona = string(zonaTemp);
    delete[] zonaTemp;

    archivo.read(reinterpret_cast<char*>(&anilloInicio), sizeof(int));
    archivo.read(reinterpret_cast<char*>(&anilloFin), sizeof(int));
}
