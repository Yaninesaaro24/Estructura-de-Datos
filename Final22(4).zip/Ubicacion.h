#pragma once
#include <string>
#include <fstream>

using namespace std;

class Ubicacion {
private:
    string zona;
    int anilloInicio;
    int anilloFin;

public:
    Ubicacion();
    void registrarUbicacion();
    string getZona() const;
    int getAnilloInicio() const;
    int getAnilloFin() const;

    void setZona(const string& zona);
    void setAnilloInicio(int anilloInicio);
    void setAnilloFin(int anilloFin);

    void guardarEnArchivo(ofstream& archivo) const;
    void cargarDesdeArchivo(ifstream& archivo);
};

