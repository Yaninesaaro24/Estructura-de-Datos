#include "Pago.h"

void Pago::realizarPago(double monto, const string& moneda, const string& metodo) {
    this->monto = monto;
    this->moneda = moneda;
    this->metodo = metodo;
    this->timestamp = time(nullptr);
    guardarTransaccion();
    cout << "----------------------------------------\n";
    cout << "Pago realizado con exito. Recibo generado:\n";
    cout << "Metodo: " << metodo << "\n";
    cout << "Monto: " << monto << " " << moneda << "\n";

    char buf[80];
    tm timeinfo;
    localtime_s(&timeinfo, &timestamp);
    strftime(buf, sizeof(buf), "%Y-%m-%d %X", &timeinfo);
    cout << "Fecha y Hora: " << buf << "\n";
    cout << "----------------------------------------\n";
}

void Pago::guardarTransaccion() const {
    ofstream outFile("transacciones.dat", ios::app | ios::binary);
    if (outFile.is_open()) {
        int metodoLen = metodo.size();
        outFile.write(reinterpret_cast<const char*>(&metodoLen), sizeof(int));
        outFile.write(metodo.c_str(), metodoLen);
        outFile.write(reinterpret_cast<const char*>(&monto), sizeof(double));
        int monedaLen = moneda.size();
        outFile.write(reinterpret_cast<const char*>(&monedaLen), sizeof(int));
        outFile.write(moneda.c_str(), monedaLen);
        outFile.write(reinterpret_cast<const char*>(&timestamp), sizeof(time_t));
        outFile.close();
    }
    else {
        cout << "Error al guardar la transaccion.\n";
    }
}

int Pago::mostrarMenuPago() {
    cout << "========================================\n";
    cout << "         Seleccione el metodo de pago   \n";
    cout << "========================================\n";
    cout << "1. Tarjeta de Credito/Debito\n";
    cout << "2. Cartera Digital\n";
    cout << "3. Transferencia Bancaria\n";
    cout << "----------------------------------------\n";
    cout << "Ingrese su opcion: ";
    int opcion;
    cin >> opcion;
    return opcion;
}

bool Pago::confirmarCompra() {
    cout << "----------------------------------------\n";
    cout << "Esta a punto de pagar una membresia de $15.\n";
    cout << "�Desea continuar? (s/n): ";
    char confirmacion;
    cin >> confirmacion;
    cout << "----------------------------------------\n";
    return (confirmacion == 's' || confirmacion == 'S');
}

bool Pago::realizarPago() {
    double monto = 15.00;
    string moneda = "USD";

    int opcion = mostrarMenuPago();

    if (confirmarCompra()) {
        switch (opcion) {
        case 1:
            realizarPago(monto, moneda, "Tarjeta de Credito/Debito");
            return true;
        case 2:
            realizarPago(monto, moneda, "Cartera Digital");
            return true;
        case 3:
            realizarPago(monto, moneda, "Transferencia Bancaria");
            return true;
        default:
            cout << "Opcion no valida. Por favor seleccione un metodo de pago valido.\n";
            return false;
        }
    }
    else {
        cout << "Pago cancelado.\n";
        return false;
    }
}
                         