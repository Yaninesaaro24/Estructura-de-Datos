#include "RegistroServicios.h"
#include <iostream>

using namespace std;

RegistroServicios::RegistroServicios() {}

void RegistroServicios::registrar() {
    int opcion;
    cout << "Seleccione el tipo de servicio:\n";
    cout << "1. Mantenimiento Preventivo\n";
    cout << "2. Mantenimiento Correctivo\n";
    cin >> opcion;

    switch (opcion) {
    case 1:
        registroMantenimientoPreventivo.registrar();
        break;
    case 2:
        registroMantenimientoCorrectivo.registrar();
        break;
    default:
        cout << "Opci�n no v�lida.\n";
        break;
    }
}

void RegistroServicios::mostrar() const {
    cout << "Mantenimiento Preventivo:\n";
    registroMantenimientoPreventivo.mostrar();
    cout << "\nMantenimiento Correctivo:\n";
    registroMantenimientoCorrectivo.mostrar();
}
