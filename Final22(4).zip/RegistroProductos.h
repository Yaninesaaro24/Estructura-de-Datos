#pragma once
#include <string>
#include <fstream>
#include "RegistroAccesorios.h"
#include "RegistroRepuestos.h"

using namespace std;

class RegistroProductos {
private:
    RegistroAccesorios registroAccesorios;
    RegistroRepuestos registroRepuestos;

public:
    RegistroProductos();
    void registrar();
    void mostrar() const;
};
