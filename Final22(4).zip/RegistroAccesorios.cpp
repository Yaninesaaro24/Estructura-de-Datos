#include "RegistroAccesorios.h"
#include <fstream>
#include <iostream>

using namespace std;

RegistroAccesorios::RegistroAccesorios() : tope(nullptr) {}

RegistroAccesorios::~RegistroAccesorios() {
    while (tope != nullptr) {
        NodoAccesorio* temp = tope;
        tope = tope->siguiente;
        delete temp;
    }
}

void RegistroAccesorios::guardarAccesorio(const NodoAccesorio* accesorio) const {
    ofstream outFile("accesorios.dat", ios::app | ios::binary);
    if (outFile.is_open()) {
        int nombreLen = accesorio->nombre.size();

        outFile.write(reinterpret_cast<const char*>(&nombreLen), sizeof(int));
        outFile.write(accesorio->nombre.c_str(), nombreLen);
        outFile.write(reinterpret_cast<const char*>(&accesorio->precio), sizeof(float));

        outFile.close();
        cout << "Accesorio registrado con exito.\n";
    }
    else {
        cout << "Error al registrar el accesorio.\n";
    }
}

void RegistroAccesorios::registrar() {
    int opcion1, opcion2;
    cout << "Seleccione la categoria de accesorio:\n";
    cout << "1. Liquidos y Lubricantes\n";
    cout << "2. Neumaticos y Ruedas\n";
    cout << "3. Productos de Limpieza y Mantenimiento\n";
    cin >> opcion1;

    string nombre;
    float precio;
    bool valido = true;

    switch (opcion1) {
    case 1:
        cout << "Seleccione el liquido o lubricante:\n";
        cout << "1. Aceite de motor (80-200 Bs.)\n";
        cout << "2. Liquido de frenos (50-100 Bs.)\n";
        cin >> opcion2;
        if (opcion2 == 1) {
            nombre = "Aceite de motor";
            cout << "Ingrese el precio (80-200 Bs.): ";
            cin >> precio;
            valido = (precio >= 80 && precio <= 200);
        }
        else if (opcion2 == 2) {
            nombre = "Liquido de frenos";
            cout << "Ingrese el precio (50-100 Bs.): ";
            cin >> precio;
            valido = (precio >= 50 && precio <= 100);
        }
        else {
            cout << "Opcion no valida.\n";
            return;
        }
        break;
    case 2:
        cout << "Seleccione el neumatico o rueda:\n";
        cout << "1. Neumaticos (300-1000 Bs.)\n";
        cin >> opcion2;
        if (opcion2 == 1) {
            nombre = "Neumaticos";
            cout << "Ingrese el precio (300-1000 Bs.): ";
            cin >> precio;
            valido = (precio >= 300 && precio <= 1000);
        }
        else {
            cout << "Opcion no valida.\n";
            return;
        }
        break;
    case 3:
        cout << "Seleccione el producto de limpieza y mantenimiento:\n";
        cout << "1. Cera para autos (50-150 Bs.)\n";
        cout << "2. Limpiadores de interiores (50-100 Bs.)\n";
        cin >> opcion2;
        if (opcion2 == 1) {
            nombre = "Cera para autos";
            cout << "Ingrese el precio (50-150 Bs.): ";
            cin >> precio;
            valido = (precio >= 50 && precio <= 150);
        }
        else if (opcion2 == 2) {
            nombre = "Limpiadores de interiores";
            cout << "Ingrese el precio (50-100 Bs.): ";
            cin >> precio;
            valido = (precio >= 50 && precio <= 100);
        }
        else {
            cout << "Opcion no valida.\n";
            return;
        }
        break;
    default:
        cout << "Opcion no valida.\n";
        return;
    }

    if (!valido) {
        cout << "El precio ingresado no esta en el rango permitido. Registro cancelado.\n";
        return;
    }

    NodoAccesorio* nuevoAccesorio = new NodoAccesorio(nombre, precio);
    nuevoAccesorio->siguiente = tope;
    tope = nuevoAccesorio;
    guardarAccesorio(nuevoAccesorio);
}

void RegistroAccesorios::mostrar() const {
    ifstream inFile("accesorios.dat", ios::binary);
    if (!inFile) {
        cerr << "Error al abrir el archivo" << endl;
        return;
    }

    while (inFile.peek() != EOF) {
        int nombreLen;
        inFile.read(reinterpret_cast<char*>(&nombreLen), sizeof(int));

        char* nombreBuffer = new char[nombreLen + 1];
        inFile.read(nombreBuffer, nombreLen);
        nombreBuffer[nombreLen] = '\0';
        string nombre = string(nombreBuffer);
        delete[] nombreBuffer;

        float precio;
        inFile.read(reinterpret_cast<char*>(&precio), sizeof(float));

        cout << "Nombre: " << nombre << endl;
        cout << "Precio: " << precio << " Bs." << endl;
    }

    inFile.close();
}
