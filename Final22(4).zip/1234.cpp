#include "Sistema.h"

int main() {
    Sistema sistema;
    sistema.iniciar();
    return 0;
}