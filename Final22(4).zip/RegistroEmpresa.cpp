#include "RegistroEmpresa.h"
#include <iostream>
#include <fstream>

using namespace std;

RegistroEmpresa::RegistroEmpresa() {}

void RegistroEmpresa::registrarEmpresa() {
    cout << "Ingrese el nombre de la empresa: ";
    cin.ignore();
    getline(cin, nombre);
    cout << "Ingrese el NIT de la empresa: ";
    cin >> nit;
    cout << "Ingrese el tipo de empresa: ";
    cin.ignore();
    getline(cin, tipoEmpresa);

    ubicacion.registrarUbicacion();

    ofstream archivo("empresas.dat", ios::binary | ios::app);
    guardarEnArchivo(archivo);
    archivo.close();
}

void RegistroEmpresa::mostrarEmpresa() const {
    cout << "Nombre: " << nombre << endl;
    cout << "NIT: " << nit << endl;
    cout << "Tipo de Empresa: " << tipoEmpresa << endl;
    cout << "Zona: " << ubicacion.getZona() << endl;
    cout << "Anillo Inicial: " << ubicacion.getAnilloInicio() << endl;
    cout << "Anillo Final: " << ubicacion.getAnilloFin() << endl;
}

void RegistroEmpresa::modificarEmpresa() {
    cout << "Modificar datos de la empresa" << endl;
    cout << "1. Nombre" << endl;
    cout << "2. NIT" << endl;
    cout << "3. Tipo de Empresa" << endl;
    cout << "4. Ubicaci�n" << endl;
    cout << "Seleccione una opci�n: ";
    int opcion;
    cin >> opcion;

    switch (opcion) {
    case 1:
        cout << "Ingrese el nuevo nombre de la empresa: ";
        cin.ignore();
        getline(cin, nombre);
        break;
    case 2:
        cout << "Ingrese el nuevo NIT de la empresa: ";
        cin >> nit;
        break;
    case 3:
        cout << "Ingrese el nuevo tipo de empresa: ";
        cin.ignore();
        getline(cin, tipoEmpresa);
        break;
    case 4:
        ubicacion.registrarUbicacion();
        break;
    default:
        cout << "Opci�n no v�lida" << endl;
        return;
    }

    ofstream archivo("empresas.dat", ios::binary | ios::app);
    guardarEnArchivo(archivo);
    archivo.close();
}

void RegistroEmpresa::guardarEnArchivo(ofstream& archivo) const {
    int nombreLen = nombre.size();
    int nitLen = nit.size();
    int tipoEmpresaLen = tipoEmpresa.size();

    archivo.write(reinterpret_cast<const char*>(&nombreLen), sizeof(int));
    archivo.write(nombre.c_str(), nombreLen);
    archivo.write(reinterpret_cast<const char*>(&nitLen), sizeof(int));
    archivo.write(nit.c_str(), nitLen);
    archivo.write(reinterpret_cast<const char*>(&tipoEmpresaLen), sizeof(int));
    archivo.write(tipoEmpresa.c_str(), tipoEmpresaLen);

    ubicacion.guardarEnArchivo(archivo);
}

bool RegistroEmpresa::cargarDesdeArchivo(const string& nitBuscado) {
    ifstream archivo("empresas.dat", ios::binary);
    if (archivo.is_open()) {
        while (archivo.peek() != EOF) {
            int nombreLen, nitLen, tipoEmpresaLen;

            archivo.read(reinterpret_cast<char*>(&nombreLen), sizeof(int));
            char* nombreTemp = new char[nombreLen + 1];
            archivo.read(nombreTemp, nombreLen);
            nombreTemp[nombreLen] = '\0';
            nombre = string(nombreTemp);
            delete[] nombreTemp;

            archivo.read(reinterpret_cast<char*>(&nitLen), sizeof(int));
            char* nitTemp = new char[nitLen + 1];
            archivo.read(nitTemp, nitLen);
            nitTemp[nitLen] = '\0';
            nit = string(nitTemp);
            delete[] nitTemp;

            archivo.read(reinterpret_cast<char*>(&tipoEmpresaLen), sizeof(int));
            char* tipoEmpresaTemp = new char[tipoEmpresaLen + 1];
            archivo.read(tipoEmpresaTemp, tipoEmpresaLen);
            tipoEmpresaTemp[tipoEmpresaLen] = '\0';
            tipoEmpresa = string(tipoEmpresaTemp);
            delete[] tipoEmpresaTemp;

            if (nit == nitBuscado) {
                ubicacion.cargarDesdeArchivo(archivo);
                archivo.close();
                return true;
            }
        }
        archivo.close();
    }
    return false;
}

Ubicacion RegistroEmpresa::getUbicacion() const {
    return ubicacion;
}
