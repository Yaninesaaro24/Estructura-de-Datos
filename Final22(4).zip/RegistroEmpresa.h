#pragma once
#include <string>
#include <fstream>
#include "Ubicacion.h"

using namespace std;

class RegistroEmpresa {
private:
    string nombre;
    string nit;
    string tipoEmpresa;
    Ubicacion ubicacion;

public:
    RegistroEmpresa();
    void registrarEmpresa();
    void mostrarEmpresa() const;
    void modificarEmpresa();
    void guardarEnArchivo(ofstream& archivo) const;
    bool cargarDesdeArchivo(const string& nitBuscado);

    Ubicacion getUbicacion() const;
};
