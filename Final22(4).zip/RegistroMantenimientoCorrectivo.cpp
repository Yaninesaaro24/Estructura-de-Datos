#include "RegistroMantenimientoCorrectivo.h"
#include <fstream>
#include <iostream>

using namespace std;

RegistroMantenimientoCorrectivo::RegistroMantenimientoCorrectivo() : frente(nullptr), fondo(nullptr) {}

RegistroMantenimientoCorrectivo::~RegistroMantenimientoCorrectivo() {
    while (frente != nullptr) {
        NodoServicioCorrectivo* temp = frente;
        frente = frente->siguiente;
        delete temp;
    }
}

void RegistroMantenimientoCorrectivo::guardarServicio(const NodoServicioCorrectivo* servicio) const {
    ofstream outFile("mantenimiento_correctivo.dat", ios::app | ios::binary);
    if (outFile.is_open()) {
        int nombreLen = servicio->nombre.size();

        outFile.write(reinterpret_cast<const char*>(&nombreLen), sizeof(int));
        outFile.write(servicio->nombre.c_str(), nombreLen);
        outFile.write(reinterpret_cast<const char*>(&servicio->precio), sizeof(float));
        outFile.write(reinterpret_cast<const char*>(&servicio->duracion), sizeof(int));

        outFile.close();
        cout << "Servicio registrado con exito.\n";
    }
    else {
        cout << "Error al registrar el servicio.\n";
    }
}

void RegistroMantenimientoCorrectivo::registrar() {
    int opcion;
    cout << "Seleccione el servicio de mantenimiento correctivo:\n";
    cout << "1. Reemplazo de Pastillas de Freno (200-400 Bs. 1-2 horas)\n";
    cout << "2. Cambio de Amortiguadores (600-1600 Bs. 2-4 horas)\n";
    cout << "3. Reparacion de la Direccion (800-2000 Bs. 4-6 horas)\n";
    cout << "4. Reemplazo de Embrague (1500-3000 Bs. 8-16 horas)\n";
    cin >> opcion;

    string nombre;
    float precio;
    int duracion;
    bool valido = true;

    switch (opcion) {
    case 1:
        nombre = "Reemplazo de Pastillas de Freno";
        cout << "Ingrese el precio (200-400 Bs.): ";
        cin >> precio;
        valido = (precio >= 200 && precio <= 400);
        duracion = 60 + (rand() % 61); // 1-2 horas
        break;
    case 2:
        nombre = "Cambio de Amortiguadores";
        cout << "Ingrese el precio (600-1600 Bs.): ";
        cin >> precio;
        valido = (precio >= 600 && precio <= 1600);
        duracion = 120 + (rand() % 121); // 2-4 horas
        break;
    case 3:
        nombre = "Reparacion de la Direccion";
        cout << "Ingrese el precio (800-2000 Bs.): ";
        cin >> precio;
        valido = (precio >= 800 && precio <= 2000);
        duracion = 240 + (rand() % 121); // 4-6 horas
        break;
    case 4:
        nombre = "Reemplazo de Embrague";
        cout << "Ingrese el precio (1500-3000 Bs.): ";
        cin >> precio;
        valido = (precio >= 1500 && precio <= 3000);
        duracion = 480 + (rand() % 481); // 8-16 horas
        break;
    default:
        cout << "Opcion no valida.\n";
        return;
    }

    if (!valido) {
        cout << "El precio ingresado no esta en el rango permitido. Registro cancelado.\n";
        return;
    }

    NodoServicioCorrectivo* nuevoServicio = new NodoServicioCorrectivo(nombre, precio, duracion);
    if (fondo == nullptr) {
        frente = fondo = nuevoServicio;
    }
    else {
        fondo->siguiente = nuevoServicio;
        fondo = nuevoServicio;
    }
    guardarServicio(nuevoServicio);
}

void RegistroMantenimientoCorrectivo::mostrar() const {
    ifstream inFile("mantenimiento_correctivo.dat", ios::binary);
    if (!inFile) {
        cerr << "Error al abrir el archivo" << endl;
        return;
    }

    while (inFile.peek() != EOF) {
        int nombreLen;
        inFile.read(reinterpret_cast<char*>(&nombreLen), sizeof(int));

        char* nombreBuffer = new char[nombreLen + 1];
        inFile.read(nombreBuffer, nombreLen);
        nombreBuffer[nombreLen] = '\0';
        string nombre = string(nombreBuffer);
        delete[] nombreBuffer;

        float precio;
        inFile.read(reinterpret_cast<char*>(&precio), sizeof(float));

        int duracion;
        inFile.read(reinterpret_cast<char*>(&duracion), sizeof(int));

        cout << "Nombre: " << nombre << endl;
        cout << "Precio: " << precio << " Bs." << endl;
        cout << "Duracion: " << duracion << " minutos" << endl;
    }

    inFile.close();
}
