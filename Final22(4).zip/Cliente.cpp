#include "Cliente.h"

using namespace std;

Cliente::Cliente(const string& nombreUsuario, const string& contrasena, const string& tipo)
    : nombreUsuario(nombreUsuario), contrasena(contrasena), tipo(tipo), esPremium(false), siguiente(nullptr) {}

Cliente::~Cliente() {}

void Cliente::limpiarPantalla() const {
    system("CLS"); // Funciona en Windows
}

void Cliente::guardarCliente() const {
    ofstream archivo("clientes.dat", ios::binary | ios::app);
    if (archivo.is_open()) {
        int nombreLen = nombreUsuario.size();
        int passLen = contrasena.size();
        int tipoLen = tipo.size();
        archivo.write(reinterpret_cast<const char*>(&nombreLen), sizeof(nombreLen));
        archivo.write(nombreUsuario.c_str(), nombreLen);
        archivo.write(reinterpret_cast<const char*>(&passLen), sizeof(passLen));
        archivo.write(contrasena.c_str(), passLen);
        archivo.write(reinterpret_cast<const char*>(&tipoLen), sizeof(tipoLen));
        archivo.write(tipo.c_str(), tipoLen);
        archivo.write(reinterpret_cast<const char*>(&esPremium), sizeof(esPremium));
        archivo.close();
    }
    else {
        cout << "No se pudo abrir el archivo para guardar el cliente" << endl;
    }
}

bool Cliente::existeCliente(const string& nombreUsuario) const {
    ifstream archivo("clientes.dat", ios::binary);
    if (archivo.is_open()) {
        while (archivo.peek() != EOF) {
            int nombreLen;
            archivo.read(reinterpret_cast<char*>(&nombreLen), sizeof(nombreLen));
            string nombre;
            nombre.resize(nombreLen);
            archivo.read(&nombre[0], nombreLen);

            int passLen, tipoLen;
            archivo.read(reinterpret_cast<char*>(&passLen), sizeof(passLen));
            archivo.ignore(passLen);
            archivo.read(reinterpret_cast<char*>(&tipoLen), sizeof(tipoLen));
            archivo.ignore(tipoLen);

            bool esPremiumTemp;
            archivo.read(reinterpret_cast<char*>(&esPremiumTemp), sizeof(esPremiumTemp));

            if (nombre == nombreUsuario) {
                archivo.close();
                return true;
            }
        }
        archivo.close();
    }
    return false;
}

bool Cliente::registrarCliente() {
    if (existeCliente(nombreUsuario)) {
        cout << "El nombre de usuario ya existe. Por favor, elija otro." << endl;
        return false;
    }
    guardarCliente();
    return true;
}

bool Cliente::iniciarSesion(const string& nombreUsuario, const string& contrasena) {
    ifstream archivo("clientes.dat", ios::binary);
    if (archivo.is_open()) {
        while (archivo.peek() != EOF) {
            int nombreLen;
            archivo.read(reinterpret_cast<char*>(&nombreLen), sizeof(nombreLen));
            string nombre;
            nombre.resize(nombreLen);
            archivo.read(&nombre[0], nombreLen);

            int passLen;
            archivo.read(reinterpret_cast<char*>(&passLen), sizeof(passLen));
            string pass;
            pass.resize(passLen);
            archivo.read(&pass[0], passLen);

            int tipoLen;
            archivo.read(reinterpret_cast<char*>(&tipoLen), sizeof(tipoLen));
            string tipo;
            tipo.resize(tipoLen);
            archivo.read(&tipo[0], tipoLen);

            bool esPremiumTemp;
            archivo.read(reinterpret_cast<char*>(&esPremiumTemp), sizeof(esPremiumTemp));

            if (nombre == nombreUsuario && pass == contrasena) {
                archivo.close();
                this->nombreUsuario = nombreUsuario;
                this->contrasena = contrasena;
                this->tipo = tipo;
                this->esPremium = esPremiumTemp;
                return true;
            }
        }
        archivo.close();
    }
    return false;
}

string Cliente::getTipo() const {
    return tipo;
}

string Cliente::getNombreUsuario() const {
    return nombreUsuario;
}

Cliente* Cliente::getSiguiente() const {
    return siguiente;
}

void Cliente::setSiguiente(Cliente* siguiente) {
    this->siguiente = siguiente;
}

void Cliente::buscarProductos() const {
    int opcion;
    BuscarProductos buscarProductos;
    while (true) {
        limpiarPantalla();
        cout << "==============================\n";
        cout << "       Buscar Producto        \n";
        cout << "==============================\n";
        cout << "1. Mostrar todos los productos\n";
        cout << "2. Filtrar por precio\n";
        cout << "3. Filtrar por ubicacion\n";
        cout << "4. Salir\n";
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        if (cin.fail() || opcion < 1 || opcion > 4) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Opcion no valida. Presione Enter para intentar de nuevo.";
            cin.ignore();
            cin.get();
            continue;
        }

        switch (opcion) {
        case 1:
            buscarProductos.buscar();
            break;
        case 2:
            buscarProductos.filtrarPorPrecio();
            break;
        case 3:
            buscarProductos.filtrarPorUbicacion();
            break;
        case 4:
            return;
        }
        cin.ignore();
        cin.get();
    }
}

void Cliente::buscarServicios() const {
    int opcion;
    BuscarServicios buscarServicios;
    while (true) {
        limpiarPantalla();
        cout << "==============================\n";
        cout << "       Buscar Servicio        \n";
        cout << "==============================\n";
        cout << "1. Mostrar todos los servicios\n";
        cout << "2. Filtrar por precio\n";
        cout << "3. Filtrar por ubicacion\n";
        cout << "4. Salir\n";
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        if (cin.fail() || opcion < 1 || opcion > 4) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Opcion no valida. Presione Enter para intentar de nuevo.";
            cin.ignore();
            cin.get();
            continue;
        }

        switch (opcion) {
        case 1:
            buscarServicios.buscar();
            break;
        case 2:
            buscarServicios.filtrarPorPrecio();
            break;
        case 3:
            buscarServicios.filtrarPorUbicacion();
            break;
        case 4:
            return;
        }
        cin.ignore();
        cin.get();
    }
}

void Cliente::controlMantenimientoPreventivo() const {
    ControlMantenimientoPreventivo controlMantenimiento;
    controlMantenimiento.menuControlMantenimiento();
}

void Cliente::cuentaPremium() {
    if (!esPremium) {
        Pago pago;
        if (pago.realizarPago()) {
            esPremium = true;
            guardarCliente();  // Actualizar el estado premium en el archivo
            cout << "Cuenta premium activada." << endl;
            controlMantenimientoPreventivo();
        }
        else {
            cout << "El pago ha fallado. No se pudo activar la cuenta premium." << endl;
        }
    }
    else {
        cout << "Ya tiene una cuenta premium." << endl;
        controlMantenimientoPreventivo();
    }
}
