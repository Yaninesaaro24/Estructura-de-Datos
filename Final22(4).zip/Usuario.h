#pragma once
#include <string>
#include <fstream>
#include <iostream>
#include "Cliente.h"
#include "Empresa.h"

using namespace std;

class Usuario {
private:
    string nombreUsuario;
    string contrasena;
    string tipo;

    void limpiarPantalla() const;

public:
    Usuario();
    Usuario(const string& nombreUsuario, const string& contrasena, const string& tipo);
    bool registrarUsuario();
    bool iniciarSesion(const string& nombreUsuario, const string& contrasena);
    string getNombreUsuario() const;
    string getContrasena() const;
    string getTipo() const;

    void buscarProductos() const;
    void buscarServicios() const;
    void cuentaPremium() const;
};
